/*
  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This is the main file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.8
        Device            :  PIC18F26K22
        Driver Version    :  2.00
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

#include "mcc_generated_files/mcc.h"
#include "mcc_generated_files/pin_manager.h"
#include "mcc_generated_files/i2c2_master.h"
#include "mcc_generated_files/spi1.h"
#include "mcc_generated_files/interrupt_manager.h"
#include "mcc_generated_files/pin_manager.h"
#include "mcc_generated_files/examples/i2c2_master_example.h"
#include "mcc_generated_files/eusart1.h"
#include "mcc_generated_files/eusart2.h"
#include "mcc_generated_files/device_config.h"
#include "mcc_generated_files/epwm3.h"
#include "stdio.h"
#include "string.h"
#include <stdint.h>
#include <xc.h>
#include <pic18.h>

//i2c address
#define HallEffect_Address 0x36 // 0b0110110 in binary
#define HallEffect_Register_H 0x0C //Raw Angle High Byte
#define HallEffect_Register_L 0x0D //Raw Angle Low Byte

#define Humidity_Address 0x27 //0b100111 in binary. Address of the Humidity Sensor

#define Temperature_Address 0b1001100// Address of the Temperature Sensor
#define Temperature_Register 0x00

//spi variables
#define fwd 0b11101111
#define bwd 0b11101101
#define stp 0b11100000
uint8_t data;
uint8_t RxData;

//Servo Motor 1 variables
//#define ServoLeft 29
//#define ServoRight 55
//#define ServoFront 42

//Servo Motor 2 variables
#define ServoLeft 43
#define ServoRight 59
#define ServoFront 51


volatile uint8_t data1;
volatile uint8_t data2;

void ISR2(){
    void EUSART2_Receive_ISR(void);
    if(EUSART2_is_rx_ready())
        {
            data2 = EUSART2_Read();
            char x2 = data2;
            if(EUSART1_is_tx_ready()){
                EUSART1_Write(x2);
            }
        }
}


void ISR1(){
    void EUSART1_Receive_ISR(void);
    if(EUSART1_is_rx_ready())
        {
            data1 = EUSART1_Read();
            char x1 = data1;
            if(EUSART2_is_tx_ready())
            {
                EUSART2_Write(x1);
            }
        }
}


void RCMode(){
    
    //1
    if(Left_GetValue()==1 && Right_GetValue()==0 && Forward_GetValue()==1 && Backward_GetValue()==0){
        CSN_SetLow();
        data = SPI1_ExchangeByte(fwd);
        CSN_SetHigh();
        EPWM3_LoadDutyValue(ServoLeft);
    }
    
    //2
    if(Left_GetValue()==0 && Right_GetValue()==0 && Forward_GetValue()==1 && Backward_GetValue()==0){
        CSN_SetLow();
        data = SPI1_ExchangeByte(fwd);
        CSN_SetHigh();
        EPWM3_LoadDutyValue(ServoFront);
    }
    
    //3
    if(Left_GetValue()==0 && Right_GetValue()==1 && Forward_GetValue()==1 && Backward_GetValue()==0){
        CSN_SetLow();
        data = SPI1_ExchangeByte(fwd);
        CSN_SetHigh();
        EPWM3_LoadDutyValue(ServoRight);
    }
    
    //4
    if(Left_GetValue()==1 && Right_GetValue()==0 && Forward_GetValue()==0 && Backward_GetValue()==0){
        EPWM3_LoadDutyValue(ServoLeft);
    }
    
    //5
    if(Left_GetValue()==1 && Right_GetValue()==1 && Forward_GetValue()==1 && Backward_GetValue()==1){
        CSN_SetLow();
        data = SPI1_ExchangeByte(stp);
        CSN_SetHigh();
        EPWM3_LoadDutyValue(ServoFront);
    }
    
    //6
    if(Left_GetValue()==0 && Right_GetValue()==1 && Forward_GetValue()==0 && Backward_GetValue()==0){
        EPWM3_LoadDutyValue(ServoRight);
    }
    
    //7
    if(Left_GetValue()==1 && Right_GetValue()==0 && Forward_GetValue()==0 && Backward_GetValue()==1){
        CSN_SetLow();
        data = SPI1_ExchangeByte(bwd);
        CSN_SetHigh();
        EPWM3_LoadDutyValue(ServoLeft);
    }
    
    //8
    if(Left_GetValue()==0 && Right_GetValue()==0 && Forward_GetValue()==0 && Backward_GetValue()==1){
        CSN_SetLow();
        data = SPI1_ExchangeByte(bwd);
        CSN_SetHigh();
        EPWM3_LoadDutyValue(ServoFront);
    }
    
    //9
    if(Left_GetValue()==0 && Right_GetValue()==1 && Forward_GetValue()==0 && Backward_GetValue()==1){
        CSN_SetLow();
        data = SPI1_ExchangeByte(bwd);
        CSN_SetHigh();
        EPWM3_LoadDutyValue(ServoRight);
    }

    
}

/*
                         Main application
 */


void main(void)
{
    // Initialize the device
    SYSTEM_Initialize();
    I2C2_Initialize();
    SPI1_Initialize();
    EPWM3_Initialize();
    EUSART1_Initialize();
    EUSART2_Initialize();
    //I2C2_Initialize();

    // If using interrupts in PIC18 High/Low Priority Mode you need to enable the Global High and Low Interrupts
    // If using interrupts in PIC Mid-Range Compatibility Mode you need to enable the Global and Peripheral Interrupts
    // Use the following macros to:

    // Enable the Global Interrupts
    INTERRUPT_GlobalInterruptEnable();

    // Disable the Global Interrupts
    //INTERRUPT_GlobalInterruptDisable();

    // Enable the Peripheral Interrupts
    INTERRUPT_PeripheralInterruptEnable();

    // Disable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptDisable();
    
    //i2c variables
    
    uint8_t Angle_H = 0;
    uint8_t Angle_L = 0;
    uint16_t Angle_12_bit = 0;
    
    
    uint8_t Humidity_data[4];
    uint16_t Humidity_14_bit;
    uint16_t Temperature_14_bit;
    float Humidity_Humidity;
    float Humidity_Temperature;
    //i2c2_address_t slaveAddress = 0x36;
    //uint8_t registerAddress = 0x0F;

    uint16_t Humidity_1;
    uint16_t Humidity_2;

    uint8_t Temp;

    
    
    
    /*
    //Servo Motor Check
    EPWM3_LoadDutyValue(ServoLeft);//Left
    __delay_ms(500);
    EPWM3_LoadDutyValue(ServoRight);//Right
    __delay_ms(500);
    
    */
    EPWM3_LoadDutyValue(ServoFront);//Front
    
    
    //DC Motor Check
    SPI1_Open(SPI1_DEFAULT);
    
    /*
    CSN_SetLow();
    data = SPI1_ExchangeByte(fwd);
    CSN_SetHigh();
    __delay_ms(500);

    
    CSN_SetLow();
    data = SPI1_ExchangeByte(bwd);
    CSN_SetHigh();
    __delay_ms(500); 
     
    */
    
    CSN_SetLow();
    data = SPI1_ExchangeByte(stp);
    CSN_SetHigh();
    __delay_ms(100);
    
    
    //CSN_SetLow();
    //data = SPI1_ExchangeByte(stp);
    //CSN_SetHigh();
    //__delay_ms(100);
    
    
    while (1)
    {
        IO_LED1_SetHigh();
        //__delay_ms(100);
        //IO_LED2_SetHigh();
        //__delay_ms(500);
        //IO_LED3_SetHigh();
        //__delay_ms(500);
        //IO_LED4_SetHigh();
        //__delay_ms(500);
        
        


        // Add your application code

        
        Temp =   I2C2_Read1ByteRegister(Temperature_Address, Temperature_Register);
        __delay_ms(20);
            //printf("TemperatureSensor(C): %d degree Celsius \n\r", Temp);
        
        
        IO_LED2_SetHigh();
        //__delay_ms(50);
        
        
        
        Angle_H = I2C2_Read1ByteRegister(HallEffect_Address, HallEffect_Register_H);
        //__delay_ms(10);
        Angle_L = I2C2_Read1ByteRegister(HallEffect_Address, HallEffect_Register_L);
        //__delay_ms(10);


        
        Angle_12_bit = Angle_H << 8 | Angle_L ;  
        //printf("Data 1: %d \n\r", Angle_H);
        //printf("Data 2: %d \n\r", Angle_L);
        //printf("12 Bit Angle: %d \n\r", Angle_12_bit);
        float Angle_8 =  ((float)Angle_H/255)*360;
        float Angle_12 =  ((float)Angle_12_bit/4095)*360;
        //__delay_ms(500);
        //printf("Angle_8: %.3f degree \n\r", Angle_8);
            //printf("Angle_12: %.3f degree \n\r\n", Angle_12);
        //printf("\n\rtesting\n\r");
        
        IO_LED3_SetHigh();
        //__delay_ms(50);
        

        
        Humidity_1 = I2C2_Read1ByteRegister(Humidity_Address, Humidity_Address);//Must be used
        __delay_ms(35);//Must be used, has to be at least 30ms
        I2C2_ReadNBytes(Humidity_Address, Humidity_data, 4);
        //printf("Humidity_Read_0 = %d\n\r", Humidity_data[0]);
        //printf("Humidity_Read_1 = %d\n\r", Humidity_data[1]);
        //printf("Humidity_Read_2 = %d\n\r", Humidity_data[2]);
        //printf("Humidity_Read_3 = %d\n\r", Humidity_data[3]);
        
        //output in bit
        Humidity_14_bit = Humidity_data[0]<<9 | Humidity_data[1];
        //__delay_ms(10);
        Temperature_14_bit = Humidity_data[2]<<6 | Humidity_data[3]>>2;
        //__delay_ms(10);
        //printf("Humidity_Humidity_RAW = %d\n\r", Humidity_14_bit);
        //printf("Humidity_Temperature_RAW = %d\n\r", Temperature_14_bit);
        
        IO_LED4_SetHigh();
        //__delay_ms(50);
        
        //output in RH and degree Celsius
        Humidity_Humidity = (((float)Humidity_14_bit)/16382)*100;
        Humidity_Temperature = (((float)Temperature_14_bit)/16382)*165 - 40;
        
        //printf("Angle: %.3f degree \n\r", Angle_12);
        //printf("Relative Humidity(RH) = %0.3f %%\n\r", Humidity_Humidity);
        //printf("Temperature1= %0.3f degree Celsius\n\r", Humidity_Temperature);
        //printf("Temperature2: %d degree Celsius\n\r", Temp);
        printf("Angle=   %.3f degree\r", Angle_12);
        printf("Relative Humidity(RH)=  %0.3f%%\r", Humidity_Humidity);
        printf("Temp2=   %d degree Celsius\r", Temp);
        printf("Temp1=   %0.3f degree Celsius\r", Humidity_Temperature);
        
        
        
        while(Forward_GetValue()==1 || Backward_GetValue()==1 || Left_GetValue()==1 || Right_GetValue()==1){
            RCMode();
        }
        CSN_SetLow();
        data = SPI1_ExchangeByte(stp);
        CSN_SetHigh();
        EPWM3_LoadDutyValue(ServoFront);
        
        //CSN_SetHigh();
        //EPWM3_LoadDutyValue(ServoFront);
        
        
        /*
        Forward_SetLow();
        Backward_SetLow();
        Left_SetLow();
        Right_SetLow();
        */
        
        IO_LED1_SetLow();
        IO_LED2_SetLow();
        IO_LED3_SetLow();
        IO_LED4_SetLow();
        __delay_ms(20);
        
        
        // Add your application code
        
    }
}
/**
 End of File
*/